# ARCHIVED REFERENCE — DO NOT IMPLEMENT

This bundle predates the approved Core AI Living Block Map v3.1.1. It is kept
only for historical comparison. The WordPress implementation in the repository
root is the source to build and deploy.

# Handoff: Core AI booth kiosk — boundary map

## Overview

An interactive kiosk screen for the WordPress Core AI booth at WCUS. It answers one question for a
passerby in about eight seconds: **how do WordPress and AI work together?** It does that by drawing
a role-based boundary map — outside assistants on the left, WordPress in the middle, outside AI
providers on the right, evaluation below the runtime — and letting a visitor tap one of four stories
to light up the path through it, or tap any block to open a detail panel.

Two designs are in this bundle:

1. **`Core AI Boundary Map.dc.html`** — archived predecessor; do not build it.
2. **`Core AI Map (current build).dc.html`** — a pixel-accurate recreation of what the
   `core-ai-map` block renders today, included as the *before* reference. Do not build this; it
   exists so you can diff intent.

## About the design files

The files in this bundle are **design references created in HTML** — prototypes showing intended
look and behavior, not production code to copy directly. They are authored as streaming Design
Components (`.dc.html`, a template + a logic class), which is an authoring format for design
review, not a shipping target.

The task is to **recreate these designs in the target codebase's existing environment**. For this
project that target is the `henryperkins/core-ai-wcus` WordPress block plugin: a dynamic block at
`src/core-ai-map/` with `render.php` (server markup), `style.scss` (styles), `view.js`
(front-end behavior via the Interactivity API), and `block.json` (attributes/defaults). Rebuild the
design there using the block's established patterns — SCSS partials, `wp-block-core-ai-map__*`
class naming, and `data-wp-*` directives — rather than porting the inline styles verbatim. Inline
styles in these files are an artifact of the design format; the shipped block should use classes.

## Fidelity

**High-fidelity.** Final colors, typography, spacing, geometry, and interaction behavior. Every
value in the Design Tokens section below is exact and taken from the design files. Recreate the UI
pixel-perfectly at 1366×1024 using the plugin's existing SCSS and Interactivity API patterns.

Two deliberately unfinished spots, both flagged in-design:

- **QR codes** are hairline-hatch placeholders (a 45°-rotated 2px line pattern) with a monospace
  "QR CODE GOES HERE" caption. Generate real QR codes for the URLs listed per panel.
- **Provider naming** is intentionally absent everywhere except the Connectors copy. Keep it that
  way; the map is vendor-neutral by decision.

## Target device

**iPad Pro 13″ — 1366×1024 landscape**, kiosk mode, single fixed viewport. No responsive behavior is
designed or required; the layout is absolutely positioned at that exact size. All coordinates below
are in that 1366×1024 space. A home-indicator pill (112×4px, `rgba(30,30,30,0.22)`, bottom 6px,
centered) is drawn as a placement guide — drop it in the real build.

Touch targets are all ≥44px; the primary CTA is 72px tall and story-rail buttons are 58px.

---

## Screens / Views

The design has three screens driven by one `screen` value: `attract` → `map` → `inspect`. They are
not separate routes; they are states of one canvas, and the transitions between them are the point.

### 1. Attract (idle)

**Purpose:** Read from six feet away. Pull a passerby into the first tap.

**Layout:** The full boundary map is already laid out in its final position underneath, at
`opacity: 0.58` with `filter: blur(0.7px)` — so the composition is legible as a shape while the
title card floats over it. Blocks drift in place (see Animations). The prompt bar, "Start over"
button, and story rail are hidden.

**Title card** — absolutely positioned, `left: 253px; top: 448px; width: 860px`,
`padding: 40px 44px 36px`, `background: rgba(255,255,255,0.94)`, `border: 1px solid #dcdcde`,
`border-radius: 4px`, `box-shadow: 0 24px 64px rgba(30,30,30,0.1)`,
`backdrop-filter: blur(8px)`, centered text. Contents top to bottom:

| Element | Spec | Copy |
| --- | --- | --- |
| Eyebrow | 12px / 700 / `0.15em` tracking / uppercase / `#3858e9` | WordPress Core AI |
| H1 | EB Garamond 64px / 500 / `line-height: 0.96` / `letter-spacing: -0.045em` / `text-wrap: balance` / `max-width: 700px` / margin-top 14px | How do WordPress and AI work together? |
| Deck | 18px / `line-height: 1.45` / `#50575e` / `max-width: 620px` / margin-top 16px / `text-wrap: pretty` | See WordPress call AI, let authorized agents call WordPress, and test what they build. |
| CTA | `min-height: 72px`, `padding: 0 26px`, `background: #3858e9`, `border: 1px solid #3858e9`, radius 4px, 18px / 650 white text, 14px gap, leading 22px plus-icon (stroke `#fff`, width 1.7) | Add the blocks to the canvas |
| Rotating story line | `min-height: 24px`, margin-top 26px, flex row `gap: 10px` align-items baseline. Label 11px / 700 / `0.1em` / uppercase / `#3858e9`; copy 15px / `#50575e` | cycles the four story titles + bodies |

**Behavior:** The story line and the map's live signal dots cycle through the four stories on a
**9000ms interval**, only while `screen === 'attract'`. Tapping the CTA goes to `map` with no story
selected. The interval keeps running but is inert off the attract screen.

### 2. Map (neutral exploration canvas)

**Purpose:** The readable state. Six WordPress blocks in fixed, meaning-carrying positions, plus a
story rail.

**Chrome (all `z-index: 40`, `top: 18px`, inset 24px, 46px tall):**

- **Wordmark** — 30×30px `assets/icon.svg` (radius 6px) + "WORDPRESS CORE AI" at 13px / 650 /
  `0.09em` / uppercase, `gap: 12px`.
- **Prompt bar** — `left: 443px`, `top: 3px`, `480×40px`, white, `1px solid #dcdcde`, radius 4px,
  `padding: 0 14px`, 15px `#50575e` text, 10px gap, 17px four-square icon stroked `#3858e9` at
  1.6. Copy: "Explore how WordPress's AI building blocks connect". Hidden on attract.
- **Offline pill** — `right: 130px`, `top: 8px`, 30px tall, `padding: 0 12px`, `background: #fff8e1`,
  `border: 1px solid #f2d675`, radius 999px, 12px / 650 / `0.06em` / uppercase / `#8a6300`, with a
  7px `#dba617` dot. Copy: "Offline mode". Shown only when the offline flag is set.
- **"Start over"** — top-right, `min-width: 100px`, `min-height: 46px`, `padding: 0 16px`, white,
  `1px solid #dcdcde`, radius 4px, 14px / 620. Hover: border and text → `#3858e9`. Hidden on
  attract. Resets to attract, story 1, idle 0.

**Boundary geometry** — the load-bearing part of the design:

- A white plate at `left: 240px; top: 112px; 790×488px`, `rgba(255,255,255,0.88)` — this is
  "inside WordPress".
- Two vertical dashed rules at **x=240** and **x=1030**, from y=112 to y=600:
  `stroke: rgba(30,30,30,0.3)`, `stroke-width: 1.2`, `stroke-dasharray: 5 7`.
- One horizontal dashed rule at **y=628**, x=240→1030: `rgba(30,30,30,0.18)`, width 1, same dash.
  This separates the runtime from evaluation.
- When a story crosses a boundary, that rule turns `#3858e9` at `stroke-width: 1.6`. Story 1
  crosses right (Connectors → provider); stories 2 and 3 cross left. Story 4 crosses nothing.
- **MCP Adapter and Connectors physically straddle their rules** — MCP Adapter sits at x=122 with
  width 236 (spanning x=122–358, crossing x=240) and Connectors at x=912 (spanning 912–1148,
  crossing x=1030). This overlap is intentional and is the whole idea: the translation layers sit
  *on* the boundary. Do not snap them inside.

**Edge labels** — 12px / 650 / `0.1em` / uppercase, at `top: 78px`:
`left: 24px` "Outside · assistants" (`#a7aaad`, width 210px) ·
`left: 256px` "Inside WordPress" (`#50575e`, weight 700) ·
`right: 24px` "Outside · AI providers" (`#a7aaad`, right-aligned) ·
`left: 256px; top: 638px` "Below the runtime · evaluation" (`#a7aaad`, hidden on attract).

**Block cards (six)** — all identical in construction, `236×148px`, `z-index: 2`:

`background: #fff`, `border: 1px solid #dcdcde`, `border-radius: 4px`,
`box-shadow: 0 1px 2px rgba(30,30,30,0.05)`, `padding: 16px`, flex column with
`justify-content: space-between`, left-aligned. Per card: a 26px line icon (`stroke: #1e1e1e`,
`stroke-width: 1.6`, round caps and joins, `fill: none`) top-left, a right-aligned status label
(12px / 650 / `0.06em` / uppercase / `#50575e`), then a title (22px / 620 /
`line-height: 1.05` / `letter-spacing: -0.02em`) and a one-line description (15px /
`line-height: 1.3` / `#50575e`, margin-top 5px).

| Block | Position (left, top) | Status label | Title | Description |
| --- | --- | --- | --- | --- |
| AI Plugin | 268, 160 | Experimental plugin | AI Plugin | Turn the foundations into useful features |
| AI Client | 556, 160 | Core API · 7.0 | AI Client | Request AI through one common interface |
| Connectors | 912, 160 | Core API · 7.0 | Connectors | Connect WordPress to providers and services |
| MCP Adapter | 122, 400 | Open adapter | MCP Adapter | Let authorized assistants work with WordPress |
| Abilities API | 556, 400 | Core API · 6.9 | Abilities API | Describe what WordPress can do |
| WP Bench | 556, 672 | Early benchmark | WP Bench | Test how well agents perform WordPress work |

Icons are 32×32 viewBox line drawings lifted from the existing block's `render.php` — reuse those
exact paths, do not redraw:

- AI Plugin: `<rect x="4" y="6" width="24" height="20" rx="2"/><path d="M9 13h9m-9 5h14"/>`
- AI Client: `<path d="M5 6h22v15H15l-6 5v-5H5V6Z"/><path d="M10 12h12m-12 4h8"/>`
- Connectors: `<path d="M13 4h6v7h5v6h-5v4a7 7 0 0 1-14 0v-4h8V4Z"/><path d="M8 17v-5m10-1V6"/>`
- MCP Adapter: `<path d="M11 5v7m10-7v7M8 12h16v3a8 8 0 0 1-8 8v4"/><path d="M12 17h8"/>`
- Abilities API: `<rect x="4" y="5" width="10" height="9" rx="1.5"/><rect x="18" y="18" width="10" height="9" rx="1.5"/><path d="M14 9.5h5a4 4 0 0 1 4 4V18M18 22.5h-5a4 4 0 0 1-4-4V14"/>`
- WP Bench: `<path d="M5 27V14m7 13V8m7 19V17m7 10V4"/><path d="M3 27h26"/>`

**Off-canvas actors (four)** — `180×100px`, `background: #fff`, **`border: 1px dashed #a7aaad`**,
radius 4px, `padding: 14px`. Dashed border is the "not WordPress" signal. Each has a kicker
(11px / 650 / `0.08em` / uppercase / `#a7aaad`), a title (18px / 620), and a line (14px /
`line-height: 1.25` / `#50575e`).

| Actor | Position | Kicker | Title | Line | Appears in |
| --- | --- | --- | --- | --- | --- |
| AI assistant | 24, 176 | Not WordPress | AI assistant | Speaks MCP | story 2 |
| Agent Skills | 24, 176 | Guidance | Agent Skills | Instruction bundles | story 3 |
| Coding agent | 24, 300 | Not WordPress | Coding agent | Writes the code | stories 3, 4 |
| AI provider | 1150, 330 | Not WordPress | AI provider | The site owner's choice | story 1 |

**These four are hidden unless the active story includes them** — the neutral canvas shows only the
six WordPress blocks. AI assistant and Agent Skills share the same slot (24, 176) and never appear
together, so no collision. Agent Skills is the only tappable actor and renders as a **stack of three
offset cards** (two decorative layers behind at `top/left: 8px` `border-color: #c3c4c7` and
`top/left: 4px` `#b4b6b9`) to read as a bundle; it is docked next to the coding agent by decision.

**Story rail** — bottom, inset 24px, `z-index: 30`, 4-column grid, `gap: 8px`. Buttons:
`min-height: 58px`, `padding: 10px 16px`, white, `1px solid #dcdcde`, radius 4px, 16px / 620 text,
`gap: 10px`, with a two-digit number at 13px / 700 / `#a7aaad`. Active state:
`background: #3858e9`, `border-color: #3858e9`, text `#fff`, number `rgba(255,255,255,0.7)`.
Labels: `01 WordPress uses AI` · `02 AI uses WordPress` · `03 An agent learns WordPress` ·
`04 WordPress tests the result`.

**Story caption** — above the rail (`bottom: 122px`, inset 24px), centered, 17px /
`line-height: 1.4` / `#50575e` / `text-wrap: pretty`, with the title inline at 650 / `#1e1e1e`.
Hidden when no story is active, on attract, and while inspecting.

**The four stories** — each dims the non-members to `opacity: 0.4` + `scale(0.945)`, tints the
members `background: #f4f6ff` with `border-color: #3858e9` and icon stroke `#3858e9`, and puts a
numbered step badge on each member: 26×26px, `background: #3858e9`, `color: #fff`, 13px / 700,
radius 3px, at `top: -11px; left: -11px`.

1. **WordPress uses AI** — AI Plugin (1) → AI Client (2) → Connectors (3) → AI provider (4).
   Crosses the right boundary. "A plugin asks for a capability. The AI Client routes the request,
   and Connectors decides which provider the site is allowed to reach."
2. **AI uses WordPress** — AI assistant (1) → MCP Adapter (2) → Abilities API (3). Crosses left.
   "An authorized assistant calls in through the MCP Adapter, which translates the call into a
   WordPress ability. Permission still belongs to WordPress."
3. **An agent learns WordPress** — Agent Skills (1) → Coding agent (2). Crosses left. "Agent Skills
   attaches current WordPress guidance to a coding assistant before it starts work. This happens
   outside the site — nothing executes here."
4. **WordPress tests the result** — Coding agent (1) → WP Bench (2). "WP Bench runs what the agent
   produced inside a sandboxed WordPress and grades it. Evidence about the work, not a leaderboard."

**Connector paths** — an SVG overlay at `viewBox="0 0 1366 1024"`, `overflow: visible`,
`pointer-events: none`, `z-index: 1`. Four hairline rest-state paths always show at
`stroke: rgba(167,170,173,0.62)`, width 1: `M504 234 L556 234`, `M792 234 L912 234`,
`M674 308 L674 400`, `M358 474 L556 474`. Active story edges draw on top at `stroke: #3858e9`,
`stroke-width: 2.4`, round caps, with an arrow marker (`refX 8.5`, `markerWidth/Height 4.6`,
`orient: auto-start-reverse`, `path d="M0 0 L10 5 L0 10 z"` filled `#3858e9`):

| Key | Path | Story |
| --- | --- | --- |
| a1 | `M504 234 L556 234` | 1 |
| a2 | `M792 234 L912 234` | 1 |
| a3 | `M1090 308 C1112 340 1122 364 1146 377` | 1 |
| b1 | `M114 276 C114 342 162 372 230 395` | 2 |
| b2 | `M358 474 L556 474` | 2 |
| c1 | `M114 278 L114 296` | 3 |
| c2 | `M204 350 C224 344 234 338 240 330` | 3 |
| d1 | `M114 402 C114 630 176 748 336 748 L546 748` | 4 |

**Signal dots** — 4.5px `#3858e9` circles running the active story's paths via `animateMotion`,
**only on the attract screen** (they advertise; they do not distract during exploration). Durations
1.4s–2.6s with staggered `begin` offsets of 0.5s / 0.6s / 1s.

### 3. Inspect (detail panel)

**Purpose:** Depth for the one visitor in ten who wants it, without leaving the map.

**Layout:** A 520px right-hand panel slides over: `top/right/bottom: 0`, `padding: 24px 32px 28px`,
`background: #fff`, `border-left: 1px solid #dcdcde`,
`box-shadow: -24px 0 64px rgba(30,30,30,0.12)`, `overflow-y: auto`, `z-index: 50`.

While it's open the whole map stage transforms `translateX(-28px) scale(0.82)` over 520ms
`cubic-bezier(0.22,1,0.36,1)`, and the story rail and caption fade to `opacity: 0`. The map stays
visible and in context — that's deliberate, the visitor should never lose their place.

**Panel contents:**

- **"← Back to the map"** — `min-height: 48px`, 14px / 620, transparent, no border; the arrow glyph
  is 20px / 400.
- **Status chip** — inline-block, `padding: 5px 9px`, `background: #eef1ff`, `color: #1e3a8a`,
  12px / 700 / `0.07em` / uppercase, radius 2px.
- **Title** — EB Garamond 54px / 500 / `line-height: 0.98` / `letter-spacing: -0.045em`.
- **Lede** — 19px / `line-height: 1.5` / `text-wrap: pretty`, margin-top 16px.
- **"How it connects"** — section label 12px / 700 / `0.1em` / uppercase / `#a7aaad`, then a flex-wrap
  row of pills, `gap: 8px`, 14px text: `padding: 7px 11px`, radius 3px. Neutral pills
  `background: #f6f7f7` `border: 1px solid #dcdcde`; the emphasized terminal pill
  `background: #eef1ff` `border: 1px solid #aab5ff`. Separated by `→` glyphs in `#3858e9`.
- **"Under the hood"** — same section label, then 15px / `line-height: 1.55` / `#50575e` body.
- **QR block** — flex row, `gap: 16px`, `padding: 16px`, `background: #f6f7f7`,
  `1px solid #dcdcde`, radius 4px, margin-top 28px. 84×84px placeholder (white, `1px solid #dcdcde`)
  + a grid of: "QR CODE GOES HERE" (IBM Plex Mono 11px / `0.06em` / uppercase / `#a7aaad`), the URL
  (15px / 620, `overflow-wrap: anywhere`), and "Keep exploring on your own device." (13px /
  `#50575e`).

**Seven panels** — six blocks plus Agent Skills:

| Panel | Chip | URL |
| --- | --- | --- |
| Abilities API | Core API · 6.9 | developer.wordpress.org/apis/abilities-api |
| AI Client | Core API · 7.0 | developer.wordpress.org/reference/functions/wp_ai_client_prompt |
| Connectors | Core API · 7.0 | make.wordpress.org/core → Connectors API in 7.0 |
| AI Plugin | Experimental reference plugin | wordpress.org/plugins/ai |
| MCP Adapter | Open adapter | github.com/WordPress/mcp-adapter |
| WP Bench | Early benchmark | github.com/WordPress/wp-bench |
| Agent Skills | Contributor guidance | github.com/WordPress/agent-skills |

Full body copy for each is in the design file; lift it verbatim. Connectors additionally has a
**"Connection states"** 2-column grid (`gap: 8px`, centered 14px pills): Available and Needs plugin
neutral, **Needs credentials** on `#fff8e1` / `1px solid #f2d675`, **Connected** on `#eef1ff` /
`1px solid #aab5ff`. Connectors is also the only panel that mentions providers at all, and it
mentions them as a category, never by name.

---

## Interactions & Behavior

| Trigger | Result |
| --- | --- |
| Idle on attract | Story cycles every 9000ms; signal dots animate; cards drift |
| Tap CTA "Add the blocks to the canvas" | → `map`, story cleared, drift pauses |
| Tap a story rail button | → `map`, story set, inspect cleared. **Tapping the active story again clears it** (toggle back to neutral) |
| Tap any block card | → `inspect`, that panel, story cleared |
| Tap the Agent Skills stack | → `inspect`, Agent Skills panel |
| Tap "← Back to the map" | → `map`, panel closed, story stays cleared |
| Tap "Start over" | → `attract`, story 1, idle counter 0, panel closed |

Off-canvas actors are not tappable except Agent Skills. Nothing navigates away from the kiosk —
there are no outbound links anywhere in this design, by design. The current build handles a tapped
link by intercepting it and showing a toast; the new design removes links entirely and uses QR codes
instead, which is the better kiosk answer.

**Transitions**

- Stage (opacity / filter): `opacity 420ms ease, filter 420ms ease`
- Stage (transform on inspect): `transform 520ms cubic-bezier(0.22,1,0.36,1)`,
  `transform-origin: 6% 50%`
- Block card state: `border-color 200ms ease, background 200ms ease, opacity 300ms ease,
  transform 300ms ease`
- Story rail button: `color 180ms ease, background 180ms ease, border-color 180ms ease`
- Actor show/hide: `opacity 320ms ease`
- Boundary rule color change: instant (no transition — the crossing should register as a snap)

**Animations** — three float keyframes, all `ease-in-out infinite`, `animation-play-state: running`
on attract and **`paused` everywhere else**. Pausing is not an optimization; a still canvas is what
makes the map readable during exploration.

```css
@keyframes caiFloatA { 0%,100% { transform: translateY(0);     } 50% { transform: translateY(-5px); } }
@keyframes caiFloatB { 0%,100% { transform: translateY(0);     } 50% { transform: translateY(5px);  } }
@keyframes caiFloatC { 0%,100% { transform: translateY(-3px);  } 50% { transform: translateY(4px);  } }
```

Durations per element, chosen to avoid visible sync: AI Plugin 6s (A), AI Client 6.6s (B),
Connectors 7.2s (A), Abilities 6.9s (C), MCP Adapter 7.6s (B), WP Bench 7.9s (A),
AI assistant 7s (C), Agent Skills 6.4s (A), Coding agent 7.4s (B), AI provider 6.8s (A).

**Reduced motion** — a `prefers-reduced-motion: reduce` block collapses all animation and
transition durations to `0.01ms`. Keep it.

**Offline** — a boolean that swaps the header status for the "Offline mode" pill. The kiosk is
expected to run without network; QR codes mean it never needs one.

## State Management

Three values plus an idle counter:

```
screen  : 'attract' | 'map' | 'inspect'   (default 'attract')
story   : '' | 'usesAi' | 'usesWp' | 'learns' | 'tests'
inspect : '' | 'abilities' | 'client' | 'connectors' | 'plugin' | 'mcp' | 'bench' | 'skills'
idle    : 0..3   (attract-loop cursor)
offline : boolean
```

Invariants worth preserving in the port:

- `story` and `inspect` are mutually exclusive — opening a panel clears the story, picking a story
  clears the panel.
- `screen === 'inspect'` is only meaningful with a non-empty `inspect`.
- The 9000ms interval must early-return unless `screen === 'attract'`, or the story silently changes
  under a visitor who is reading.
- No data fetching. No persistence. Everything is static content compiled into the block. For the
  WordPress port these map naturally onto Interactivity API context plus `block.json` attributes for
  the defaults.

## Design Tokens

Straight from the WordPress admin palette the block already uses (`src/core-ai-map/style.scss`).
No invented colors.

**Color**

| Token | Value | Use |
| --- | --- | --- |
| Canvas | `#f6f7f7` | Page background, neutral pills |
| Surface | `#ffffff` | Cards, panel, chrome |
| WordPress plate | `rgba(255,255,255,0.88)` | Inside-WordPress region |
| Title card | `rgba(255,255,255,0.94)` | Attract card |
| Ink | `#1e1e1e` | Primary text |
| Ink secondary | `#50575e` | Body, descriptions |
| Ink tertiary | `#a7aaad` | Labels, kickers, rest-state edges |
| Accent | `#3858e9` | Active state, arrows, CTA, links |
| Accent deep | `#1e3a8a` | Chip text, link hover |
| Accent tint | `#eef1ff` | Chips, emphasized pills |
| Accent tint (card) | `#f4f6ff` | Active block card fill |
| Accent border | `#aab5ff` | Emphasized pill border |
| Hairline | `#dcdcde` | All borders |
| Dashed (outside) | `#a7aaad` | Actor card borders |
| Dashed stack | `#c3c4c7`, `#b4b6b9` | Agent Skills stack layers |
| Boundary rule | `rgba(30,30,30,0.3)` | Vertical dashed rules |
| Runtime rule | `rgba(30,30,30,0.18)` | Horizontal dashed rule |
| Warning bg | `#fff8e1` | Offline pill, "Needs credentials" |
| Warning border | `#f2d675` | ditto |
| Warning dot | `#dba617` | Offline dot |
| Warning ink | `#8a6300` | Offline text |
| Grid line | `rgba(30,30,30,0.03)` | 56px background grid |

Note: the current build assigns a **per-project accent** to each node icon (`#674399` Agent Skills,
`#087e8b` AI Client, `#c94c34` AI Plugin, `#008a20` MCP Adapter, `#8a6300` WP Bench). The new
design **drops those** in favor of one accent — six competing hues fought the boundary reading at
distance. Don't reintroduce them.

**Typography**

| Role | Stack |
| --- | --- |
| UI / body | `Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif` — 400/500/600/700 |
| Display | `'EB Garamond', Georgia, serif` — 500 |
| Mono | `'IBM Plex Mono', monospace` — 400/500 |

Scale in use: 11, 12, 13, 14, 15, 16 (base), 17, 18, 19, 22, 54, 64px. Weights: 400, 500, 620,
650, 700 — the 620/650 pair is intentional and does real work separating card titles from labels.
Body `line-height: 1.45`; display `0.96`–`0.98`; display `letter-spacing: -0.045em`, card titles
`-0.02em`, uppercase labels `+0.06em` to `+0.15em`.

**Geometry**

- Radius: `2px` chips · `3px` pills and step badges · `4px` everything structural · `6px` wordmark ·
  `50%` dots · `999px` pills and the home indicator. **No large radii anywhere** — WordPress admin
  is a 4px-radius system and the design holds that line.
- Shadows: `0 1px 2px rgba(30,30,30,0.05)` cards · `0 24px 64px rgba(30,30,30,0.1)` title card ·
  `-24px 0 64px rgba(30,30,30,0.12)` panel.
- Screen inset: `24px`. Background grid: `56px`.
- Card sizes: `236×148` blocks · `180×100` actors · `520` panel width · `480×40` prompt bar.

## Assets

- **`assets/icon.svg`** — copied verbatim from the repo at `assets/icon.svg`. Used as the 30px
  wordmark. Ship the repo's file; don't redraw it.
- **Block icons** — the six 32×32 line paths listed above, taken from the existing block's
  `render.php`. Reuse verbatim.
- **QR placeholders** — an SVG `<pattern>` (`caiQr`, 4×4, `patternTransform="rotate(45)"`, a 2px
  `#dcdcde` line). Replace with generated QR codes.
- **Fonts** — Google Fonts: Inter (400,500,600,700), EB Garamond (400,500), IBM Plex Mono (400,500).
  A kiosk that runs offline must **self-host these**; the Google Fonts `<link>` in the design files
  is a prototype convenience and will fail on the booth network. This is the one thing in the
  bundle that must change for production.
- No photography or illustration. None is needed.

## Files

| File | What it is |
| --- | --- |
| `Core AI Boundary Map.dc.html` | **The design to build.** All three screens, all four stories, all seven panels. |
| `Core AI Map (current build).dc.html` | Pixel-accurate recreation of today's shipping block, for reference/diff only. |
| `support.js` | Runtime for the `.dc.html` format. Required to open the files locally; not part of the deliverable. |
| `assets/icon.svg` | The wordmark asset, from the repo. |
| `github.md` | Source association: repo, branch, `path: src/core-ai-map`, and the screen → source-file map. |
| `screenshots/` | Nine reference captures, each a true 1366×1024 frame. See below. |

### Screenshots

All captured at exactly 1366×1024, 1× — measure against these.

| File | State |
| --- | --- |
| `01-attract.png` | Attract screen, idle loop on story 1 |
| `02-map-neutral.png` | Neutral exploration canvas, no story |
| `03-story-wordpress-uses-ai.png` | Story 1 — AI Plugin → AI Client → Connectors → provider, right rule lit |
| `04-story-ai-uses-wordpress.png` | Story 2 — assistant → MCP Adapter → Abilities, left rule lit |
| `05-story-agent-learns-wordpress.png` | Story 3 — Agent Skills → coding agent, outside the boundary |
| `06-story-wordpress-tests-result.png` | Story 4 — coding agent → WP Bench, below the runtime |
| `07-inspect-connectors.png` | Inspect panel open, map pushed back and scaled |
| `08-current-build-map.png` | **Reference only** — today's shipping block, map state |
| `09-current-build-detail.png` | **Reference only** — today's shipping block, detail state |

To view either design, open the `.dc.html` file in a browser with `support.js` and `assets/`
alongside it, as they are in this bundle.

**Source files these were built from** (`henryperkins/core-ai-wcus`, branch `main`):
`src/core-ai-map/render.php` · `src/core-ai-map/style.scss` · `src/core-ai-map/block.json` ·
`src/core-ai-map/view.js` · `core-ai-map.php` · `assets/icon.svg`.

## Open decisions

Two things a developer should not resolve alone:

1. **WCUS 2026 site theme.** The design uses the WordPress admin palette from the plugin's own
   `style.scss`, not the WCUS 2026 event theme. Whether the booth kiosk should match the event site
   is still open with the design owner.
2. **QR destinations.** The URLs above are the canonical project docs, but the final codes may want
   to point at a single booth landing page with the six links on it instead of six separate codes.
