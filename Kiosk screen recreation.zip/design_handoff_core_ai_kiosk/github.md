repo: henryperkins/core-ai-wcus
branch: main
path: src/core-ai-map

## Last sync

date: 2026-08-12T05:17:36Z

### Updated in this project

- Recreated the shipping kiosk block (attract, map, scenario, detail) as a 1366×1024 Design Component.
- Added a redesigned role-based boundary map: outside assistants | inside WordPress | outside providers, WP Bench below the runtime.
- Replaced the six-node orbit and hub with fixed, meaning-carrying positions; MCP Adapter and Connectors straddle the dashed boundary.
- Revised the block set and status labels per the WCUS research notes (Connectors promoted, Agent Skills made contextual).

## Screen map

| Project screen | Built from |
| --- | --- |
| Core AI Map (current build).dc.html | src/core-ai-map/render.php, src/core-ai-map/style.scss, src/core-ai-map/block.json, src/core-ai-map/view.js, core-ai-map.php |
| Core AI Boundary Map.dc.html | src/core-ai-map/style.scss (tokens, type, spacing), src/core-ai-map/render.php (icon paths), src/core-ai-map/block.json (copy), assets/icon.svg |
| assets/icon.svg | assets/icon.svg (copied verbatim) |
